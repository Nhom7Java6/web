package edu.poly.dao;


import edu.poly.model.Share;

public class ShareDao extends AbstractEntityDao<Share>{

	public ShareDao() {
		super(Share.class); 

}
}
