package edu.poly.dao;



import edu.poly.model.Video;

public class VideoDao extends AbstractEntityDao<Video> {
public VideoDao() {
		super(Video.class);
		
	}



}
