package edu.poly.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import edu.poly.model.User;

public class UserDao extends AbstractEntityDao<User> {

    public UserDao() {
        super(User.class);
    }

    public void changePassword(String username, String oldPassword, String newPassword) throws Exception {
        EntityManager em = JpaUtils.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        String jpql = "SELECT u FROM User u WHERE u.username = :username AND u.password = :password";

        try {
            trans.begin();

            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("username", username);
            query.setParameter("password", oldPassword);

            User user = query.getSingleResult();
            user.setPassword(newPassword);

            em.merge(user);
            trans.commit();
        } catch (javax.persistence.NoResultException e) {
            trans.rollback();
            throw new Exception("Current Password or Username are incorrect");
        } catch (Exception e) {
            trans.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public User findByUsernameAndEmail(String username, String email) {
        EntityManager em = JpaUtils.getEntityManager();
        String jpql = "SELECT u FROM User u WHERE u.username = :username AND u.email = :email";

        try {
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("username", username);
            query.setParameter("email", email);

            return query.getSingleResult();
        } catch (javax.persistence.NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public User findByUsername(String username) {
        EntityManager em = JpaUtils.getEntityManager();
        String jpql = "SELECT u FROM User u WHERE u.username = :username";

        try {
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("username", username);

            return query.getSingleResult();
        } catch (javax.persistence.NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public boolean existsByUsername(String username) {
        EntityManager em = JpaUtils.getEntityManager();
        String jpql = "SELECT COUNT(u) FROM User u WHERE u.username = :username";

        try {
            Long count = em.createQuery(jpql, Long.class)
                           .setParameter("username", username)
                           .getSingleResult();
            return count > 0;
        } finally {
            em.close();
        }
    }
}
